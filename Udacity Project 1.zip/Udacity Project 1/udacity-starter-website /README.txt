Deploy Static Website on AWS



In this cloud, I deployed a static website to AWS using S3, CloudFront and IAM. 

The URL to access the website are shown below 

http://my-353449663403-bucket.s3-website-us-east-1.amazonaws.com/

https://d25q3eczhi4h9b.cloudfront.net/index.html

http://my-353449663403-bucket.s3-website-us-east-1.amazonaws.com




